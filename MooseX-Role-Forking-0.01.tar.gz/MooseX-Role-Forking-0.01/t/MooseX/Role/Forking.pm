package t::MooseX::Role::Forking;

use Test::More;

use base 'Test::Class';

sub test_load_implementer : Tests {
   my $job = new Test::Forkable;

   ok (blessed $job);

   ok ($job->run);

   my $seconds_slept = Test::Forkable::sleep_undisturbed (1);

   ok ($seconds_slept > 0);

   ok ($job->has_ended);

   is ($job->exit_code, 22);

   $job->reset;

   $job->abandon_filehandles;

   ok (not $job->has_ended);
   
   ok (not $job->exit_code);

   ok ($job->run(42));

   sleep(1);

   ok($job->has_ended);

   is($job->exit_code, 42);
}

sub test_multiple_objects : Tests {
   my @jobs;

   my $num_jobs = 10;

   close STDOUT;
   open STDOUT, '>', undef or die "Can't open STDOUT into temporary file : $!";

   push (@jobs, new Test::Forkable) for (1..$num_jobs);

   my $i = 0;

   foreach my $job (@jobs) {
      $job->abandon_filehandles if ++$i % 2;
      $job->run(int (rand 50));
   }

   my $has_ended = 0;

   while (!$has_ended) {
      foreach my $job (@jobs) {
         $has_ended = $job->has_ended;
         last if not $has_ended;
      }
      sleep 1 unless $has_ended;
   }

   seek (STDOUT, 0, 0);

   my @stdout = <STDOUT>;

   is (scalar @stdout, int ($num_jobs / 2));
}

package Test::Forkable;
use Moose;

with 'MooseX::Role::Forking';

sub job {
   my $self = shift;
   my $exit_code = shift || 22;

   print "This is my job, i exit with $exit_code\n";

   return $exit_code;
}
