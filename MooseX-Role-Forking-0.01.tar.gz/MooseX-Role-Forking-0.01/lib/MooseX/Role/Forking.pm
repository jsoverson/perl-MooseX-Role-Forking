package MooseX::Role::Forking;

use POSIX qw( :sys_wait_h );
use Scalar::Util 'refaddr';
use Carp;
use Moose::Exporter;

Moose::Exporter->setup_import_methods(
   as_is => [ 'sleep_undisturbed' ],
);

use Moose::Role;

our $VERSION = '0.01';

requires 'job';

has forked_pid    => ( is => 'ro', writer => '_forked_pid' );
has has_ended     => ( is => 'ro', writer => '_has_ended' );
has is_registered => ( is => 'ro', writer => '_is_registered' );
has address       => ( is => 'ro', writer => '_address' );
has id            => ( is => 'ro', writer => '_id' );
has exit_code     => ( is => 'ro', writer => '_exit_code' );
has _abandon_filehandles   => ( is => 'rw' );

sub sleep_undisturbed {
   my $seconds = shift;

   my $seconds_slept = 0;
   while ($seconds_slept <= $seconds) {
      $seconds_slept += sleep($seconds - $seconds_slept);
   }
   return $seconds_slept;
}

{
   my $PARENTS = {};
   my $CHILDREN = {};

   $SIG{CHLD} = sub {
      while ((my $pid = waitpid( -1, WNOHANG)) > 0) {
         my $parent_id = $CHILDREN->{$pid};
         my $parent = $PARENTS->{$parent_id};

         return if not $parent; #we've already been destroyed

         $parent->_has_ended(1);
         $parent->_exit_code($? >> 8);
         delete $CHILDREN->{$pid};
      }
   };

   sub run {
      my $self = shift;

      $self->_register;

      if ($self->forked_pid && not $self->has_ended) {
         carp 'Previous child (' . $self->forked_pid . ') has not ended, can not start another.';
         return;
      }

      my $pid = fork;

      if ($pid) {
         $self->_forked_pid($pid);
         $self->_register_child;
         return $pid;
      }

      if ($self->_abandon_filehandles) {
         open STDIN, '/dev/null';
         open STDOUT, '/dev/null';
         open STDERR, '/dev/null';
      }

      my $rv = $self->job(@_);

      $self->_has_ended(1);
      
      exit($rv);
   }

   sub abandon_filehandles {
      my $self = shift;

      $self->_abandon_filehandles(1);
   }

   sub reset {
      my $self = shift;
      
      delete $CHILDREN->{$self->forked_pid};
      $self->_forked_pid(undef);
      $self->_has_ended(0);
      $self->_exit_code(undef);
   }

   sub _register {
      my $self = shift;
      
      return if $self->is_registered;

      $self->_address(refaddr $self);
      $self->_id($$ . '-' . $self->address);
      $self->_is_registered(1);
      $PARENTS->{$self->id} = $self;

      return 1;
   }

   sub _register_child {
      my $self = shift;

      my $pid = $self->forked_pid;

      $CHILDREN->{$pid} = $self->id();
   }

   sub DESTROY {
      my $self = shift;
      return if not $self->id;
      
      delete $PARENTS->{$self->id};
   }

}

1;
__END__

=head1 NAME

MooseX::Role::Forking 

=head1 VERSION

Version 0.01

=cut

=head1 SYNOPSIS

Quick summary of what the module does.

Perhaps a little code snippet.

    use Moose;

    my $foo = MooseX::Role::Forking->new();
    ...

=head1 BUGS

Please report any bugs or feature requests to C<bug-moosex-role-forking at rt.cpan.org>, or through
the web interface at L<http://rt.cpan.org/NoAuth/ReportBug.html?Queue=MooseX-Role-Forking>.  I will be notified, and then you'll
automatically be notified of progress on your bug as I make changes.

=head1 SUPPORT

You can find documentation for this module with the perldoc command.

    perldoc MooseX::Role::Forking


You can also look for information at:

=over 4

=item * RT: CPAN's request tracker

L<http://rt.cpan.org/NoAuth/Bugs.html?Dist=MooseX-Role-Forking>

=item * AnnoCPAN: Annotated CPAN documentation

L<http://annocpan.org/dist/MooseX-Role-Forking>

=item * CPAN Ratings

L<http://cpanratings.perl.org/d/MooseX-Role-Forking>

=item * Search CPAN

L<http://search.cpan.org/dist/MooseX-Role-Forking/>

=back

=head1 ACKNOWLEDGEMENTS

=head1 COPYRIGHT & LICENSE

Copyright 2009 Jarrod Overson.

This program is free software; you can redistribute it and/or modify it
under the terms of either: the GNU General Public License as published
by the Free Software Foundation; or the Artistic License.

See http://dev.perl.org/licenses/ for more information.

=cut
